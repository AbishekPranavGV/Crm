const ValidationService = {

  email: function(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || '').trim());
  },

  required: function(object, fields) {
    const missing = fields.filter(function(field) {
      return object[field] === undefined ||
             object[field] === null ||
             object[field] === '';
    });

    if (missing.length) {
      throw new Error('Missing required fields: ' + missing.join(', '));
    }
  }
};