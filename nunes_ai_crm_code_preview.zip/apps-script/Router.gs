function getCrmDashboard() {
  return {
    products: 1248,
    pendingReview: 24,
    priceRecords: 2847,
    extractionsToday: 386
  };
}

function getGmailAccounts() {
  return GmailAccountService.list();
}

function setActiveSenderAccount(accountId) {
  return GmailAccountService.setActive(accountId);
}

function validateCommunication(request) {
  return CommunicationService.validate(request);
}