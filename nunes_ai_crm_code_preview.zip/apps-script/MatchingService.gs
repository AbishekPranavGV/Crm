const MatchingService = {

  normalize: function(value) {
    return String(value || '')
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .trim();
  },

  score: function(candidate, product) {
    let score = 0;

    if (candidate.sku && product.sku &&
        this.normalize(candidate.sku) === this.normalize(product.sku)) {
      score += 0.60;
    }

    if (candidate.partNumber && product.partNumber &&
        this.normalize(candidate.partNumber) === this.normalize(product.partNumber)) {
      score += 0.30;
    }

    if (candidate.name && product.name &&
        this.normalize(candidate.name) === this.normalize(product.name)) {
      score += 0.10;
    }

    return Math.min(score, 1);
  }
};