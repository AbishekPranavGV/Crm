const ProductService = {

  search: function(query) {
    // Replace with a batch Sheet read against Products.
    return [];
  },

  createCandidate: function(candidate) {
    if (!candidate) throw new Error('Candidate is required.');

    // Write to Product_Candidates first.
    // Never write uncertain AI output directly to Products.
    return candidate;
  }
};