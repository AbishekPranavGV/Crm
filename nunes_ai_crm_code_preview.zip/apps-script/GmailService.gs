const GmailService = {

  searchCurrentUserMailbox: function(query, maxResults) {
    return GmailApp.search(
      query || '',
      0,
      Math.min(maxResults || 20, 100)
    ).map(function(thread) {
      return {
        threadId: thread.getId(),
        subject: thread.getFirstMessageSubject()
      };
    });
  },

  send: function(request) {
    /*
     * DO NOT use this method for arbitrary account switching.
     *
     * Production multi-account sending should call the approved
     * Gmail API/OAuth sender adapter.
     */
    throw new Error(
      'Multi-account Gmail sending requires the approved OAuth/Gmail API adapter.'
    );
  }
};