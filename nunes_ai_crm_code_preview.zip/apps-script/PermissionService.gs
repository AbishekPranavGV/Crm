const PermissionService = {

  canSend: function(crmUserId, senderAccountId) {
    if (!crmUserId || !senderAccountId) return false;

    // Production:
    // Read Sender_Permissions and require:
    // CRM_User_ID = crmUserId
    // Sender_Account_ID = senderAccountId
    // Can_Send = TRUE
    // Status = ACTIVE

    return true; // Demo only.
  },

  assertCanSend: function(crmUserId, senderAccountId) {
    if (!this.canSend(crmUserId, senderAccountId)) {
      throw new Error('You do not have permission to send from this Gmail account.');
    }
  }
};