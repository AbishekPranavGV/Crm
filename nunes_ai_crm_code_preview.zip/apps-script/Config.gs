const CONFIG = Object.freeze({
  SHEETS: {
    GMAIL_ACCOUNTS: 'Gmail_Accounts',
    SENDER_PERMISSIONS: 'Sender_Permissions',
    PRODUCTS: 'Products',
    PRODUCT_CANDIDATES: 'Product_Candidates',
    PRICES: 'Prices',
    DOCUMENTS: 'Documents',
    BUYERS: 'Buyers',
    EMAIL_TEMPLATES: 'Email_Templates',
    LOCATIONS: 'Locations',
    OUTREACH: 'Outreach',
    COMM_LOG: 'Communication_Log',
    OAUTH_AUDIT: 'OAuth_Audit'
  },
  CONFIDENCE: {
    HIGH: 0.95,
    REVIEW: 0.85
  }
});

function getSpreadsheet_() {
  const id = PropertiesService.getScriptProperties()
    .getProperty('SPREADSHEET_ID');
  return id ? SpreadsheetApp.openById(id) : SpreadsheetApp.getActiveSpreadsheet();
}