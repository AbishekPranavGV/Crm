/**
 * OAuth boundary.
 *
 * IMPORTANT:
 * Do not put Gmail passwords or OAuth access/refresh tokens in:
 * - HTML
 * - Google Sheets
 * - client-side JavaScript
 *
 * For separate Google accounts, connect an approved OAuth 2.0 /
 * Gmail API implementation here.
 *
 * For Google Workspace, company-approved delegation may be preferable.
 */

const GmailOAuthService = {

  getAuthorizationUrl: function() {
    throw new Error(
      'Configure your company-approved Google OAuth 2.0/Gmail API client first.'
    );
  },

  handleCallback: function(request) {
    throw new Error(
      'Configure the OAuth callback using the approved company deployment.'
    );
  },

  revoke: function(accountId) {
    throw new Error(
      'Configure OAuth token revocation for account: ' + accountId
    );
  }
};