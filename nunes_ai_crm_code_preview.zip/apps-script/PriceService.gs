const PriceService = {

  extractPriceCandidate: function(text, source) {
    // NLP price extraction adapter.
    return {
      source: source || {},
      productName: '',
      price: '',
      currency: '',
      confidence: 0,
      status: 'NEEDS_REVIEW'
    };
  }
};