const CommunicationService = {

  validate: function(request) {

    ValidationService.required(request, [
      'crmUserId',
      'senderAccountId',
      'recipient',
      'templateId',
      'documentIds',
      'channel'
    ]);

    if (request.channel === 'GMAIL' &&
        !ValidationService.email(request.recipient)) {
      throw new Error('Invalid recipient email.');
    }

    PermissionService.assertCanSend(
      request.crmUserId,
      request.senderAccountId
    );

    const files = request.documentIds.map(function(id) {
      return DriveService.getFileMeta(id);
    });

    return {
      ok: true,
      senderAccountId: request.senderAccountId,
      files: files
    };
  },

  send: function(request) {

    this.validate(request);

    // Production:
    // 1. Resolve template
    // 2. Resolve variables
    // 3. Resolve exact Drive files
    // 4. Resolve location/QR
    // 5. Call Gmail OAuth/API adapter
    // 6. Only after successful provider response -> SENT
    // 7. Write Communication_Log

    throw new Error(
      'Sending is disabled until the approved Gmail OAuth/API adapter is configured.'
    );
  }
};