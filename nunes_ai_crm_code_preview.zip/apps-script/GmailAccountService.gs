const GmailAccountService = {

  list: function() {
    // Production: read connected accounts from Gmail_Accounts.
    // OAuth tokens must NOT be stored in this sheet.
    return [
      {
        id: 'ACCOUNT_DEMO_01',
        email: 'sales@example.com',
        status: 'CONNECTED',
        canSend: true
      },
      {
        id: 'ACCOUNT_DEMO_02',
        email: 'marketing@example.com',
        status: 'CONNECTED',
        canSend: false
      }
    ];
  },

  getActive: function() {
    return PropertiesService.getUserProperties()
      .getProperty('ACTIVE_SENDER_ACCOUNT_ID') || '';
  },

  setActive: function(accountId) {
    if (!accountId) throw new Error('Sender account is required.');

    // Production: verify account belongs to current CRM user.
    PropertiesService.getUserProperties()
      .setProperty('ACTIVE_SENDER_ACCOUNT_ID', accountId);

    return { ok: true, accountId: accountId };
  },

  disconnect: function(accountId) {
    // Production: revoke OAuth authorization through approved OAuth flow.
    if (!accountId) throw new Error('Account ID is required.');
    return { ok: true, status: 'DISCONNECT_REQUIRES_OAUTH_REVOCATION' };
  }
};