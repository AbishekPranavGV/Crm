const DriveService = {

  getFileMeta: function(fileId) {
    if (!fileId) throw new Error('Drive File ID is required.');

    const file = DriveApp.getFileById(fileId);

    return {
      id: file.getId(),
      name: file.getName(),
      mimeType: file.getMimeType(),
      url: file.getUrl(),
      size: file.getSize()
    };
  },

  getBlob: function(fileId) {
    return DriveApp.getFileById(fileId).getBlob();
  }
};