const LoggingService = {

  audit: function(event) {
    console.log(JSON.stringify({
      event: event,
      timestamp: new Date().toISOString()
    }));
  },

  error: function(module, message, details) {
    console.error(JSON.stringify({
      module: module,
      message: message,
      details: details || null,
      timestamp: new Date().toISOString()
    }));
  }
};