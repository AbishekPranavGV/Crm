@echo off
setlocal
title NUNES AI Product CRM - Apps Script Builder

set "ROOT=%~dp0NUNES_AI_CRM"
mkdir "%ROOT%" 2>nul
mkdir "%ROOT%\apps-script" 2>nul
mkdir "%ROOT%\docs" 2>nul

echo Creating CRM files...

REM Copy source files from the packaged folder structure
xcopy /E /I /Y "%~dp0apps-script" "%ROOT%\apps-script" >nul
copy /Y "%~dp0SCHEMA.txt" "%ROOT%\docs\SCHEMA.txt" >nul

echo.
echo ==============================================
echo NUNES AI PRODUCT CRM CREATED
echo ==============================================
echo.
echo Apps Script files:
dir /B "%ROOT%\apps-script"
echo.
echo Open preview.html in the same folder.
echo.
start "" "%~dp0preview.html"
pause
