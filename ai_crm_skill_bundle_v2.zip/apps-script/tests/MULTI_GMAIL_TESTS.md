# Multi-Gmail test plan

1. Connect Account A through approved OAuth.
2. Connect Account B through approved OAuth.
3. Verify both appear with correct email identities.
4. Switch A -> B and verify active sender changes only for current user context.
5. User without permission selects B -> send must fail.
6. Permission revoked -> send must fail.
7. OAuth scope missing -> REAUTH_REQUIRED / no send.
8. Invalid recipient -> no send.
9. Missing template -> no send.
10. Missing Drive file -> no send.
11. Successful provider submission -> Communication_Log status SENT with Sender_Account_ID and Provider_Message_ID.
12. Provider failure -> FAILED with error code/message; never SENT.
13. Disconnect account -> cannot send until reauthorized.
14. Verify OAuth audit never contains tokens.
