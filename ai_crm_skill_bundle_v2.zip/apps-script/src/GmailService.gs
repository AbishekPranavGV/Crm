const GmailService={
 send:(request)=>{throw new Error('Use the approved Gmail API/OAuth sender adapter for multi-account sending.');},
 readAsCurrentExecutionUser:(query,max)=>GmailApp.search(query,0,Math.min(max||20,100))
};