const GmailOAuthService={
 // Adapter boundary. Use an approved OAuth 2.0/Gmail API implementation for
 // separate Google accounts. Do not store passwords or expose tokens to HTML.
 getAuthorizationUrl:()=>{throw new Error('Configure approved OAuth 2.0 provider/client for this deployment.');},
 handleCallback:()=>{throw new Error('Configure approved OAuth callback for this deployment.');},
 revoke:()=>{throw new Error('Configure approved OAuth revocation for this deployment.');}
};