const CommunicationService={
 validate:o=>{
  ValidationService.required(o,['crmUserId','senderAccountId','recipient','templateId','documentIds','channel']);
  if(o.channel==='GMAIL'&&!ValidationService.email(o.recipient))throw new Error('Invalid recipient');
  if(!PermissionService.canSend(o.crmUserId,o.senderAccountId))throw new Error('Sender permission denied');
  const files=o.documentIds.map(DriveService.meta);
  return{ok:true,senderAccountId:o.senderAccountId,files};
 },
 send:o=>{const v=CommunicationService.validate(o);LoggingService.audit({eventType:'SEND_ATTEMPT',senderAccountId:o.senderAccountId,recipient:o.recipient});throw new Error('Configure approved Gmail API/OAuth sender adapter before enabling send.');}
};