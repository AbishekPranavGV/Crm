const GmailAccountService={
 list:()=>[],
 getActive:()=>PropertiesService.getUserProperties().getProperty('ACTIVE_SENDER_ACCOUNT_ID')||'',
 setActive:(senderAccountId)=>{if(!senderAccountId)throw new Error('Sender account required');PropertiesService.getUserProperties().setProperty('ACTIVE_SENDER_ACCOUNT_ID',senderAccountId);return {ok:true,senderAccountId};},
 validate:(senderAccountId)=>{if(!senderAccountId)throw new Error('Sender account required');return {ok:false,status:'NOT_IMPLEMENTED'};}
};