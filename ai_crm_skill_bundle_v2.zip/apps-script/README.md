# Apps Script architecture

Config.gs                  configuration
Code.gs                    web entry
Router.gs                  UI endpoints
GmailAccountService.gs     account list, connection state, switching, validation
GmailOAuthService.gs       OAuth/API adapter boundary; implementation depends on approved deployment
GmailService.gs            Gmail operations
DriveService.gs            Drive metadata/files
ExtractionService.gs       NLP/OCR adapter
ProductService.gs          Product Master/candidates
MatchingService.gs         matching/deduplication
PriceService.gs            price records
CommunicationService.gs    compose/validate/send/log
PermissionService.gs       CRM-user sender permissions
ValidationService.gs       shared validation
LoggingService.gs          audit/error logging
Index.html                 UI shell
app.html                   client logic
styles.html                UI styling

Security rule:
Do not put Gmail passwords or OAuth tokens in Sheets, HTML, or client JavaScript.
