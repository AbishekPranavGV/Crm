# Sheets schema

## Gmail_Accounts
Sender_Account_ID | Email | Display_Name | Provider | Auth_Status | Scopes_Granted | Authorized_By | Authorized_At | Last_Validated_At | Active | Workspace_Domain

## Sender_Permissions
Permission_ID | Sender_Account_ID | CRM_User_ID | Can_Read | Can_Send | Allowed_From_Address | Granted_By | Granted_At | Revoked_At | Status

## Products
Product_ID | SKU | Product_Name | Model_Number | Part_Number | Brand | Category | Subcategory | Description | Specifications | Unit | Variant | Supplier_ID | Status | Created_At | Updated_At

## Product_Candidates
Candidate_ID | Run_ID | Product_ID_Match | Extracted_JSON | Confidence | Status | Gmail_Message_ID | Attachment_ID | Drive_File_ID | Source_File_Name | Source_Page | Extracted_At | Reviewed_By | Reviewed_At

## Prices
Price_ID | Product_ID | Supplier_ID | Price | Currency | Price_Type | Effective_From | Effective_To | Source_File_ID | Extracted_At | Status

## Documents
Document_ID | Product_ID | Type | File_Name | Drive_File_ID | URL | Version | Status

## Email_Templates
Template_ID | Name | Subject | Body_HTML | Status

## Locations
Location_ID | Name | Address | Maps_URL | QR_File_ID | Status

## Buyers
Buyer_ID | Company | Contact | Email | Phone | Country | Status

## Outreach
Outreach_ID | Buyer_ID | CRM_User_ID | Sender_Account_ID | Channel | Template_ID | Product_IDs | Document_IDs | Location_ID | Include_Links | Include_QR | Status | Created_At | Sent_At

## Communication_Log
Communication_ID | Outreach_ID | CRM_User_ID | Sender_Account_ID | Sender_Email | Recipient | Channel | Template_ID | Product_IDs | Document_IDs | Location_ID | Validation_Result | Status | Provider_Message_ID | Error_Code | Error_Message | Created_At | Sent_At

## OAuth_Audit
Event_ID | Sender_Account_ID | CRM_User_ID | Event_Type | Scopes | Result | Timestamp | Error_Code
