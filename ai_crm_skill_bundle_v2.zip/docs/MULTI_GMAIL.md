# Multi-Gmail account architecture

## Recommended flow
CRM user
 -> Connect Gmail
 -> Google OAuth consent
 -> authorization/token storage handled server-side
 -> Connected Gmail Accounts
 -> permission validation
 -> account selector
 -> compose
 -> pre-send validation
 -> send
 -> per-account communication log

## Important
Google Apps Script's built-in GmailApp is tied to the identity executing the script. A true arbitrary multi-account sender switch should not be implemented by storing Gmail passwords or pretending GmailApp can impersonate another account.

For separate Google accounts, use an approved OAuth 2.0 / Gmail API integration or a company-approved Workspace delegation model.

For Google Workspace, domain/admin policy may make delegated sending preferable. The final design must follow the company's IT/security rules.

## Account selector states
CONNECTED
REAUTH_REQUIRED
DISCONNECTED
PERMISSION_MISSING
SEND_NOT_ALLOWED

## Sender validation
- connected
- OAuth authorization valid
- required scope present
- permitted sender identity
- recipient valid
- template valid
- attachments accessible
- variables resolved
- location/QR valid if requested
