---
name: crm-product-intelligence
description: Build and maintain an AI/NLP-powered CRM using Gmail, Google Drive, Google Sheets and Google Apps Script, including multi-Gmail account authorization/switching, sender permissions, product extraction, price intelligence, document selection, communication automation, location QR selection, dashboards, testing and audit logging.
---

# CRM Product Intelligence + Multi-Gmail

## Mission
Build a reliable, auditable CRM in small increments.

Core pipeline:
Gmail/PDF/attachments -> ingest -> parse/OCR -> NLP extraction -> normalize -> match/deduplicate -> confidence -> human review -> Product Master -> Price association -> dashboard.

Communication:
Buyer + template + products + exact Drive files + location -> preview -> validate -> selected sender account -> Gmail/WhatsApp -> per-account log.

## Multi-Gmail architecture
Treat Gmail account identity and authorization as separate from the CRM user.

A Connected Gmail Account record must include:
- Sender_Account_ID
- Email
- Display_Name
- Provider = GOOGLE
- Auth_Status
- Scopes_Granted
- Authorized_By
- Authorized_At
- Last_Validated_At
- Active
- Workspace/Domain when applicable

Never store Gmail passwords.

Use OAuth 2.0 / Google authorization. Do not expose access tokens in client-side UI or Sheets. Prefer a server-side token/credential mechanism approved by the company. For production Google Workspace deployments, consider domain admin controls or delegated access instead of collecting credentials.

## Account switching
The UI must provide:
- current sender account
- connected accounts
- connect another account
- disconnect/revoke
- permission status
- account validation
- last-used account

Switching changes the sender context for the current communication only unless an explicit user preference is saved.

Never silently change the sender.

## Sender permissions
Before sending, validate:
1. current CRM user is authenticated
2. selected Gmail account is connected and authorized
3. required Gmail scopes exist
4. user is allowed to send from that account
5. recipient is valid
6. template is active
7. all variables resolve
8. exact Drive File IDs exist and are accessible
9. selected location/QR exists when requested

If any check fails: DO NOT SEND.

Do not claim an account can send as another address merely because the address appears in a dropdown. Verify the authorization/delegation/alias configuration.

## Gmail account security
- No passwords.
- No access tokens in HTML/JavaScript.
- No secrets in source code.
- Use PropertiesService or an approved secure secret/token store.
- Keep least-privilege scopes.
- Log authorization events without logging tokens.
- Support disconnect/revoke.
- Do not expose another user's mailbox contents merely because their account is connected.
- Respect company retention, privacy and access policies.

## Communication audit
Every send attempt must record:
Communication_ID
Outreach_ID
CRM_User_ID
Sender_Account_ID
Sender_Email
Recipient
Channel
Template_ID
Product_IDs
Document_IDs
Location_ID
Validation_Result
Status
Provider_Message_ID
Error_Code
Error_Message
Created_At
Sent_At

Allowed status examples:
DRAFT, VALIDATION_FAILED, READY, SENDING, SENT, FAILED, CANCELLED.

Only mark SENT after the Gmail provider confirms successful submission.

## Product rules
AI output is a candidate, never authoritative master data.
Preserve Gmail Message ID, Attachment ID, Drive File ID, file name, page where available and extraction timestamp.
Use stable IDs.
Ambiguous matching becomes NEEDS_REVIEW.

## Product extraction
Extract when present:
product name, SKU, model/part number, brand, category, subcategory, description, specifications, unit, variant, supplier, price, currency, effective date.

## Matching
Prefer exact identifiers, then normalized model/part number, brand+model, name+strong attributes, then semantic similarity as supporting evidence.

## Confidence
Configurable defaults:
HIGH >= 0.95
REVIEW 0.85-0.949
LOW < 0.85

## Apps Script
Separate modules:
Config, UI, GmailAccount, Gmail, Drive, Extraction, Product, Matching, Price, Communication, Validation, Logging.

Use batch Sheet reads/writes. Use LockService where concurrent writes can collide. Keep provider-specific OAuth/token logic behind a service adapter.

## Response modes
ARCHITECTURE, SCHEMA, UI, OAUTH, NLP, APPS SCRIPT, TEST, DEBUG, AUDIT, BUILD.

Do not jump to BUILD unless explicitly requested.

## Definition of done
Include happy path, failure path, permissions, source traceability, account identity, audit logging, security, tests and regression safety.
